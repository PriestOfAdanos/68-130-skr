import time


def rd(beg, end):
    tm = (time.time()) ** 3
    return tm % (end - beg) + beg


print(rd(10, 100))
