def ad(x, y):
    print(x + y)


ad(1, 2)
