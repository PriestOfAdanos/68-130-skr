import string

a = string.ascii_lowercase
b = string.ascii_lowercase + string.ascii_lowercase
d = {a[i]: b[i + 3] for i in range(len(a))}


def cezar(st):
    s = ""
    for i in st:
        s += d[i]
    return s


print(cezar("pawel"))
