def add_2_irr(i1, i2):  # (a,bi)/(a2,b2i)
    i1 = complex(*i1)
    i2 = complex(*i2)
    return i1 + i2


print(add_2_irr((1, 2), (2, 1)))
