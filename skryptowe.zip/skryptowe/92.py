from math import sin, cos, sqrt, factorial, prod, pi
import random


def a(alp, bet):
    a = 2 * sin(0.5 * (alp + bet)) * cos(0.5 * (alp - bet))
    b = 2 * sin(0.5 * (alp - bet)) * cos(0.5 * (alp + bet))
    print(a, b)


def b(x, n):
    n1 = [
        (factorial(n) / factorial(n - i)) * x ** (i) / factorial(i)
        for i in range(n + 1)
    ]
    print(sum(n1))


def c(a, b, c):
    if b ** 2 - 4 * a * c >= 0:
        x1 = (-b + sqrt(b ** 2 - 4 * a * c)) / 2 * a
        x2 = (-b - sqrt(b ** 2 - 4 * a * c)) / 2 * a
    else:
        x1 = (-b + complex(0, sqrt(-(b ** 2 - 4 * a * c)))) / (2 * a)
        x2 = (-b - complex(0, sqrt(-(b ** 2 - 4 * a * c)))) / (2 * a)
    print(x1, x2)


def d(x):
    ex = [(x ** i) / factorial(i) for i in range(1000)]
    # no python nie obsługuje nieskończoności
    print(sum(ex))


def an(n):
    if n == 1:
        return 1
    return an(n - 1) * 3


def bn(n):
    if n == 1:
        return 2
    return bn(n - 1) ** 2


def e(x, n, k, L):
    return 1 + sum(
        [
            an(i) * cos(i * pi * x / L) + bn(i) * sin(i * pi * x * n / L)
            for i in range(1, n)
        ]
    )


a(1, 2)
b(11, 2)
c(3, 1, 3)
d(10)
e(10, 10, 10, 10)
