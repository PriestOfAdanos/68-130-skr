import itertools

l1 = ["XL", "L", "M", "S"]
l2 = ["Męske", "Damskie"]
l3 = ["biały", "czarny", "zielony", "czerwony", "niebieski"]

c = list(itertools.product(l3, itertools.product(l1, l2)))

for i, metka in enumerate(c):
    with open("metki97/wyjsciezadanie97_metka{}.txt".format(i), "w+") as f:
        f.write(str(metka).replace("(", "").replace(")", ""))
