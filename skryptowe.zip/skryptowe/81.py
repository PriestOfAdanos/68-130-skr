s = input().split(",")
s = [int(x) for x in s]
l = len(s)
print("średnia", sum(s) / l)
if l % 2 == 0:
    print("mediana: ", ((s[int(l / 2)] + s[int(l / 2 - 1)])) / 2)
else:
    print("mediana: ", s[int(l / 2 - 0.5)])
