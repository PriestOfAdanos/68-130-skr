import string
import collections


def shanon(st):
    d = {i: 0 for i in string.ascii_lowercase}
    for i in st:
        d[i] += 1
    od = collections.OrderedDict(sorted(d.items()))
    sh = dict()
    val = 0
    k = ""
    for key in od:
        if od[key] > 0:
            sh[key] = val * "1" + "0"
            val += 1
            k = key
    sh[k] = "1" * (val - 1)
    encoded = ""
    for i in st:
        encoded += sh[i]
    return encoded


print(shanon("abaaabbssccsdsdc"))
