import cmath

number = input("in: ")
print("out: " + str(cmath.phase(complex(number))))
