def ul(x):
    l = x.as_integer_ratio()
    return "{}/{}".format(*l)


print(ul(0.25))
