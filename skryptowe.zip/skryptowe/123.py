import random


def rd(lst):
    return random.choice(lst)


print(rd([1, 2, 3]))
