def avg_max_min(arr):
    return min(arr), max(arr), sum(arr) / len(arr)


print(avg_max_min([1, 2, 3]))
