n = int(input("podaj n"))
x = lambda a: "więcej" if n > 0 else "mniej"
print("{} niż zero".format(x(n)))
