print(1 in [1, 2, 3])
