with open("danezadanie93.txt", "r") as f1:
    with open("wyjsciezadanie93.txt", "w") as f2:
        f2.write(f1.read().upper())
