import operator

wynik = 31 % 3
print(operator.mul(wynik, wynik + 3))
