import math


def polygon_area(n, a):  # liczba boków, długość
    return (
        n * ((a / (2 * math.sin(math.pi / n))) ** 2) * math.sin(2 * math.pi / n)
    ) / 2


print(polygon_area(4, 1))
