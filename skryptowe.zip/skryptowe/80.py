x = input()
try:
    x = float(x)
except ValueError:
    print("zła liczba")
