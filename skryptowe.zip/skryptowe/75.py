lst = [123, [456, [789, [101112]]]]
st = [[[]]]
st.append(123)
st[0][0].append("123")
st[0][0].append(True)
st[0].append(2.11111)

print(st[0] == lst[0])
