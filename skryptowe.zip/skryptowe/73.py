lst = [[[]]]
lst[0][0].append(123)
lst[0][0].append("123")
lst[0][0].append(True)
lst[0][0].append(2.11111)
print(lst)
