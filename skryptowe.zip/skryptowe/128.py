class Pow(object):
    def __init__(self, *args):
        if len(args) > 1:
            self.value = args[0] ** args[1]

    def __call__(self, *args):
        if len(args) > 1:
            self.value = args[0] ** args[1]
        return self.value


a = Pow(11, 2)
print(a())
print(a(21, 2))
