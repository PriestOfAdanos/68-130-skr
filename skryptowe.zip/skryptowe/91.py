with open("danezadanie89.txt", "r") as f:
    a = int(f.read())
    b = hex(a)
    c = oct(a)
    with open("wyjsciezadanie89.txt", "w") as f2:
        f2.write(str((a, b, c)))
