x = 1
for i in range(3):
    x *= i + 1
print(x)
