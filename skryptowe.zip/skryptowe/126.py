import math


class Kolo:
    def __init__(self, r):
        self.r = r

    def pole(self):
        return (self.r ** 2) * math.pi

    def obwod_i_okrog(self):
        return 2 * math.pi * self.r


a = Kolo(5)
print(a.pole())
print(a.obwod_i_okrog())
