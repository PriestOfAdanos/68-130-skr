import time


def first_mon(y, w):
    return time.asctime(time.strptime("{} {} 1".format(y, w), "%Y %W %w"))


print(first_mon(2008, 51))
