import random


def sh(lst):
    random.shuffle(lst)
    return lst


print(sh([1, 2, 3, 4]))
