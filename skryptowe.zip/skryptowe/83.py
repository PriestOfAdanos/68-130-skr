def get_int():
    x = input()
    try:
        int(x)
        assert float(x) == int(x)

    except:
        print("zła liczba")


get_int()
