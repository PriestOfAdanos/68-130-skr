import random

x = random.randrange(1, 10)
z = random.choice([1, 2, 3, 4])
with open("WYJSCIEZADANIE86.txt", "w+") as f:
    f.write("{}:{}".format(x, z))
