import timeit


import minilib.utils as mu


arr1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
arr2 = [6, 2, 4, 8, 9, 0, 8, 7, 2, 5]
arr3 = [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
print("mu.bubbleSort(arr1): ", timeit.timeit("mu.bubbleSort(arr1)", globals=locals()))
print("mu.bubbleSort(arr2): ", timeit.timeit("mu.bubbleSort(arr2)", globals=locals()))
print("mu.bubbleSort(arr3): ", timeit.timeit("mu.bubbleSort(arr3)", globals=locals()))
print("mu.quickSort(arr1): ", timeit.timeit("mu.quickSort(arr1,0,9)", globals=locals()))
print("mu.quickSort(arr1): ", timeit.timeit("mu.quickSort(arr1,0,9)", globals=locals()))
print("mu.quickSort(arr1):", timeit.timeit("mu.quickSort(arr1,0,9)", globals=locals()))
print(
    "mu.insertionSort(arr1): ",
    timeit.timeit("mu.insertionSort(arr1)", globals=locals()),
)
print(
    "mu.insertionSort(arr1)", timeit.timeit("mu.insertionSort(arr1)", globals=locals())
)
print(
    "mu.insertionSort(arr1)", timeit.timeit("mu.insertionSort(arr1)", globals=locals())
)
