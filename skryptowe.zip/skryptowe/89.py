def is_palin(st):
    return st == st[::-1]


print(is_palin("abba"))
print(is_palin("abb"))
