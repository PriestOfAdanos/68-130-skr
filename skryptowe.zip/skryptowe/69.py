import random


def monte_pirlo(acc):
    sqr, circl = 0, 0
    for i in range(acc):
        x = random.random()
        y = random.random()
        if x ** 2 + y ** 2 < 1:
            circl += 1
    return 4 * circl / acc


print(monte_pirlo(1000000))
