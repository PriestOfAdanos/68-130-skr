def fun(x):
    if x >= 0:
        return x
    if x < 0:
        return -x


print(fun(-1))
print(fun(100))
print(fun(0))
