st = "ala ma kota"
# print(len(st))

splt = reversed(st.split(" "))
rvsd = ""
for i in splt:
    rvsd += i + " "
# print(len(rvsd))
rvsd = rvsd[:-1]
# print(len(rvsd))
print(rvsd)
