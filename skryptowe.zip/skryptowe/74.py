lst = [123, [456, [789, [101112]]]]
print(lst[0])
print(lst[1][0])
print(lst[1][1][0])
print(lst[1][1][1][0])
