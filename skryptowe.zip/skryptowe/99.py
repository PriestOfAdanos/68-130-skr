import calendar


def range_leap(a, b):
    for i in range(a, b):
        if calendar.isleap(i):
            yield i


leap_years = range_leap(1900, 2000)
for i in leap_years:
    print(i, end=" ")
