import csv
from minilib.utils import *


def main():
    d = []
    with open("file.txt", "r") as f:
        d = csv.reader(f, delimiter=",", quoting=csv.QUOTE_NONNUMERIC)
        for i in d:
            print(i)
            a = bubbleSort(i)
            b = insertionSort(i)
            c = quickSort(i, 0, len(i) - 1)
            print(i)
            print(a)
            print(b)
            print(c)

        with open("file2.txt", "w+") as f:
            write(f, a)
        with open("file3.txt", "w+") as f:
            write(f, b)
        with open("file4.txt", "w+") as f:
            write(f, c)


main()
