def silnia(n):
    o = 1
    for i in range(1, n + 1):
        o *= i
    return o


print(silnia(10))
