import datetime

stt = "2018-06-29 08:15:27.243860"
objj = datetime.datetime.strptime(stt, "%Y-%m-%d %H:%M:%S.%f")

print("Date:", objj.date())
print("Time:", objj.time())
print("Date-time:", objj)
