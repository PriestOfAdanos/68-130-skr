n = input("podaj liste").split(",")
for i in n:
    print(i)
