st = "AEIOUYaeiouy"
o = dict()
for i in ["a", "e", "i", "o", "u", "y"]:
    o[i] = st.lower().count(i)

for i in o:
    print("{}: {}".format(i, o[i]))
