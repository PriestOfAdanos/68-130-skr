x = int(input("podaj mnoznik"))
y = int(input("podaj zakres"))

with open("output97.txt", "w+") as f:
    for i in range(y):
        f.write("**{}** | **{}**\n".format(i, i * x))
