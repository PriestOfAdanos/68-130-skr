vowel = {i: 0 for i in "aeiou"}
st = input("Podaj literki: ").lower()
for i in st:
    try:
        vowel[i] += 1
    except KeyError:
        pass

print(vowel)
