from datetime import datetime
import time
import sys
import os


def clock():
    while True:
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
        sys.stdout.write(current_time)
        time.sleep(1)
        os.system("clear")


clock()
