from math import e

n = 10
print([-0.7 * e + 4.07] * n)
