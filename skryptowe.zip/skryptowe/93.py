lst = input("podaj litery(i,j,k): ").split(",")
with open("pliktext.txt", "r") as f:
    t = f.read()
    for i in lst:
        print(i, ": ", t.count(i))
