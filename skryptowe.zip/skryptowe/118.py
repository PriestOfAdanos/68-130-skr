import math


def l_z_mod(a, b):  # a+bi
    return math.sqrt(a ** 2 + b ** 2)


print(l_z_mod(-2, -3))
