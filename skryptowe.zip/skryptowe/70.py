def cpx(x, y):
    return complex(x, y) ** (1 / 2)


print(cpx(2, 2))
