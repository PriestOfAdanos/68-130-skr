def silnia(n):
    if n == 1:
        return n
    return n * silnia(n - 1)


print(silnia(10))
