import random

x, y = input("x,y").split(",")
x = int(x)
y = int(y)
lst = []
print(lst)
for j in range(x):
    lst.append([random.randint(0, 10) for i in range(y)])
print(lst)
